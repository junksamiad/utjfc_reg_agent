from pydantic import BaseModel, Field, field_validator
try:
    from pydantic import EmailStr
except ImportError:
    # Fallback for development without email-validator
    EmailStr = str
from typing import Optional, Literal
from datetime import datetime
import re


class AdultRegistrationDataContract(BaseModel):
    """
    Pydantic model defining the exact data contract for writing adult registration data to the database.
    
    This model is specifically designed for adult self-registration where:
    1. The player IS the registrant (no parent/child relationship)
    2. Player details are also stored in parent fields for database compatibility
    3. Age group supports "Open Age" for adult teams
    4. Simplified validation appropriate for adult registration
    
    The AI agent will parse conversation history to populate this model.
    """
    
    # ============================================================================
    # PLAYER INFORMATION (ALL REQUIRED)
    # ============================================================================
    player_first_name: str = Field(
        ..., 
        min_length=1, 
        max_length=50,
        description="Player's first name - required, validated in routine 1"
    )
    
    player_last_name: str = Field(
        ..., 
        min_length=1, 
        max_length=50,
        description="Player's last name - required, validated in routine 1"
    )
    
    player_dob: str = Field(
        ..., 
        pattern=r'^\d{2}-\d{2}-\d{4}$',
        description="Player's date of birth in DD-MM-YYYY format - required, validated in routine 3 (must be 18+ years old)"
    )
    
    player_gender: Literal["Male", "Female", "Not Disclosed"] = Field(
        ...,
        description="Player's gender - required, normalized in routine 4"
    )
    
    age_group: str = Field(
        ..., 
        pattern=r'^(u\d{1,2}|Open Age)$',
        description="Age group in format u## (e.g., u10, u16) or 'Open Age' for adult teams - injected from registration code"
    )
    
    team: str = Field(
        ..., 
        min_length=1, 
        max_length=20,
        description="Team name (e.g., Tigers, Lions, Mens) - injected from registration code"
    )
    
    # ============================================================================
    # MEDICAL INFORMATION (REQUIRED)
    # ============================================================================
    player_has_any_medical_issues: Literal["Y", "N"] = Field(
        ...,
        description="Whether player has medical issues - required, validated in routine 5"
    )
    
    description_of_player_medical_issues: Optional[str] = Field(
        None,
        max_length=500,
        description="Details of medical issues - required if player_has_any_medical_issues='Y'"
    )
    
    # ============================================================================
    # CONTACT INFORMATION (PLAYER'S OWN DETAILS)
    # ============================================================================ 
    player_telephone: str = Field(
        ..., 
        pattern=r'^\+447\d{9}$',
        description="Player's mobile telephone number in +447xxxxxxxxx format - required, validated in routine 8"
    )
    
    player_email: EmailStr = Field(
        ...,
        description="Player's email address - required, validated in routine 9"
    )
    
    club_comms_consent: Literal["Y", "N"] = Field(
        ...,
        description="Consent to receive club communications via email/SMS - required, validated in routine 10"
    )
    
    # ============================================================================
    # ADDRESS INFORMATION (PLAYER'S ADDRESS)
    # ============================================================================
    player_postcode: str = Field(
        ..., 
        min_length=6, 
        max_length=8,
        description="Player's postcode - required, validated in routine 12"
    )
    
    player_address_line_1: str = Field(
        ..., 
        min_length=1, 
        max_length=100,
        description="Player's address line 1 - required, validated in routines 13-15"
    )
    
    player_address_line_2: Optional[str] = Field(
        None,
        max_length=100,
        description="Player's address line 2 - optional"
    )
    
    player_town: str = Field(
        ..., 
        min_length=1, 
        max_length=50,
        description="Player's town/city - required, validated in routines 13-15"
    )
    
    # ============================================================================
    # PREVIOUS SEASON INFORMATION
    # ============================================================================
    played_for_urmston_town_last_season: Literal["Y", "N"] = Field(
        ...,
        description="Whether player played for Urmston Town last season - required, validated in routine 6"
    )
    
    previous_team_last_season: Optional[str] = Field(
        None,
        max_length=50,
        description="Name of previous team if didn't play for Urmston Town - optional"
    )
    
    # ============================================================================
    # DATABASE COMPATIBILITY FIELDS
    # These fields map the player's details to parent fields for database compatibility
    # ============================================================================
    parent_first_name: Optional[str] = Field(
        None,
        description="Mapped from player_first_name for database compatibility"
    )
    
    parent_last_name: Optional[str] = Field(
        None,
        description="Mapped from player_last_name for database compatibility" 
    )
    
    parent_relationship_to_player: Literal["Self"] = Field(
        default="Self",
        description="Always 'Self' for adult registration - player is registering themselves"
    )
    
    parent_telephone: Optional[str] = Field(
        None,
        description="Mapped from player_telephone for database compatibility"
    )
    
    parent_email: Optional[str] = Field(
        None,
        description="Mapped from player_email for database compatibility"
    )
    
    parent_dob: Optional[str] = Field(
        None,
        description="Mapped from player_dob for database compatibility"
    )
    
    parent_postcode: Optional[str] = Field(
        None,
        description="Mapped from player_postcode for database compatibility"
    )
    
    parent_address_line_1: Optional[str] = Field(
        None,
        description="Mapped from player_address_line_1 for database compatibility"
    )
    
    parent_address_line_2: Optional[str] = Field(
        None,
        description="Mapped from player_address_line_2 for database compatibility"
    )
    
    parent_town: Optional[str] = Field(
        None,
        description="Mapped from player_town for database compatibility"
    )
    
    # ============================================================================
    # SYSTEM FIELDS
    # ============================================================================
    registree_role: Literal["Player"] = Field(
        default="Player",
        description="Always 'Player' for adult registration - adult is registering themselves"
    )
    
    registration_code: str = Field(
        ...,
        max_length=50,
        description="The registration code used to start this registration process"
    )
    
    # ============================================================================
    # PAYMENT INFORMATION (ALL REQUIRED FOR ADULT REGISTRATION)
    # ============================================================================
    billing_request_id: str = Field(
        ..., 
        min_length=10, 
        max_length=50,
        description="GoCardless billing request ID - returned from create_payment_token function"
    )
    
    preferred_payment_day: int = Field(
        ..., 
        ge=-1, 
        le=31,
        description="Day of month for monthly payments (1-31 or -1 for last day) - validated in routine 29"
    )
    
    # ============================================================================
    # PAYMENT AMOUNTS (CONVERTED FROM PENCE TO POUNDS)
    # ============================================================================
    signing_on_fee_amount: Optional[float] = Field(
        None,
        ge=0,
        description="One-off signing fee amount in pounds (converted from pence by create_payment_token function)"
    )
    
    monthly_subscription_amount: Optional[float] = Field(
        None,
        ge=0,
        description="Monthly subscription amount in pounds (converted from pence by create_payment_token function)"
    )
    
    # ============================================================================
    # PAYMENT STATUS FIELDS (DEFAULTS)
    # ============================================================================
    signing_on_fee_paid: Literal["Y", "N"] = Field(
        default="N",
        description="Whether signing fee has been paid - defaults to 'N'"
    )
    
    mandate_authorised: Literal["Y", "N"] = Field(
        default="N",
        description="Whether Direct Debit mandate has been authorised - defaults to 'N'"
    )
    
    subscription_activated: Literal["Y", "N"] = Field(
        default="N",
        description="Whether monthly subscription is active - defaults to 'N'"
    )
    
    registration_status: Literal["pending_payment", "active", "suspended", "incomplete"] = Field(
        default="pending_payment",
        description="Current registration status - defaults to 'pending_payment'"
    )
    
    payment_follow_up_count: int = Field(
        default=0,
        ge=0,
        description="Number of follow-up reminders sent - defaults to 0"
    )
    
    # ============================================================================
    # REGISTRATION TYPE AND SEASON (INJECTED FROM CODE)
    # ============================================================================
    registration_type: Literal["100", "200"] = Field(
        ...,
        description="Registration type - 100=re-registration, 200=new registration - injected from code"
    )
    
    season: Literal["2526"] = Field(
        ...,
        description="Season code - currently 2526 for 2025-26 season - injected from code"
    )
    
    @field_validator('player_dob')
    @classmethod
    def validate_adult_dob(cls, v: str) -> str:
        """Validate that DOB represents an adult (18+ years old)."""
        if not re.match(r'^\d{2}-\d{2}-\d{4}$', v):
            raise ValueError('Date must be in DD-MM-YYYY format')
        
        # Parse date and check if 18+
        day, month, year = v.split('-')
        birth_year = int(year)
        current_year = datetime.now().year
        
        if birth_year > 2007:  # Must be 18+ (born in 2007 or earlier)
            raise ValueError('Player must be 18 or older (born in 2007 or earlier)')
        
        return v
    
    @field_validator('age_group')
    @classmethod
    def validate_age_group_format(cls, v: str) -> str:
        """Validate age group format for adult teams."""
        if not re.match(r'^(u\d{1,2}|Open Age)$', v):
            raise ValueError('Age group must be in format u## or "Open Age"')
        return v
    
    def model_post_init(self, __context) -> None:
        """Auto-populate parent fields from player fields for database compatibility."""
        if not self.parent_first_name:
            self.parent_first_name = self.player_first_name
        if not self.parent_last_name:
            self.parent_last_name = self.player_last_name
        if not self.parent_telephone:
            self.parent_telephone = self.player_telephone
        if not self.parent_email:
            self.parent_email = self.player_email
        if not self.parent_dob:
            self.parent_dob = self.player_dob
        if not self.parent_postcode:
            self.parent_postcode = self.player_postcode
        if not self.parent_address_line_1:
            self.parent_address_line_1 = self.player_address_line_1
        if not self.parent_address_line_2:
            self.parent_address_line_2 = self.player_address_line_2
        if not self.parent_town:
            self.parent_town = self.player_town