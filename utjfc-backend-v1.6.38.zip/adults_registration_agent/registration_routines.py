class RegistrationRoutines:
    """
    Manages the step-by-step routine messages for adult player self-registration flow.
    These messages get dynamically injected into the agent's system prompt based on routine_number.
    """
    
    ROUTINES = {
        1: """Task: Your current task is to: 1) take the player's first and last name which should result in at least 2 parts (first name + last name) 2) validate that it contains only letters, apostrophes, hyphens, and spaces - convert any curly apostrophes (', ', etc.) to straight apostrophes (') 3) ensure it's at least 2 words long and not just single letters 4) if invalid format or too short, set routine_number = 1 and ask for clarification but do not mention validation checks 5) if valid, call function check_if_record_exists_in_db to see if this is a returning player. If they are not a returning player (ie a record match IS NOT returned) then set routine_number = 3 and ask for their date of birth. 6) if a record is returned, check the value of 'played_for_urmston_town_last_season'. If 'N', set routine_number = 32 and ask them to choose their kit size. The kits come in sizes: S, M, L, XL, 2XL, 3XL. Show the sizes in a clear format and ask them to choose. 7) If 'played_for_urmston_town_last_season' is 'Y', call check_if_kit_needed. If result = 'N', set routine = 34 and explain they need to upload a passport-style photo for ID purposes. 8) If check_if_kit_needed = 'Y', set routine_number = 32 and ask them to choose their kit size.""",
        
        # Skip routine 2 - not needed for adult self-registration
        
        3: """Task: Your current task is to: 1) take the player's date of birth 2) accept any date format (DD/MM/YYYY, MM/DD/YYYY, DD-MM-YYYY, etc.) and convert to DD-MM-YYYY format 3) validate that birth year is 2007 or earlier (must be 18+ years old), not in the future, and is a real date 4) if invalid date or after 2007, set routine_number = 3 and politely explain they must be 18 or over to register for the adult team 5) if valid, set routine_number = 4 and ask for their gender.""",
        
        4: """Task: Your current task is to: 1) take the player's gender response 2) ensure the response is one of: 'Male', 'Female', or 'Not disclosed' (accept variations like 'man/woman', 'prefer not to say', etc. and normalize them) 3) If the response cannot be understood or normalized, set routine_number = 4 and ask for clarification 4) If a valid gender is provided, set routine_number = 5 and ask whether they have any known medical issues that the club should be aware of.""",
        
        5: """Task: Your current task is to: 1) take the response about whether they have any known medical issues 2) accept Yes/No response (normalize 'y', 'yeah', 'nope', etc.) 3) if Yes, ask for details and structure into a clean list separated by commas - remove prefixes like 'I have', 'suffer from' and capitalize properly 4) **IMPORTANT**: if any serious medical conditions are mentioned (allergies requiring EpiPen/medication, asthma inhaler, diabetes, epilepsy, heart conditions, etc.), ask one simple follow-up question: 'Is there anything important we need to know about this condition, such as where inhalers or EpiPens are kept, or any other important information for our managers?' 5) keep it simple - don't dig too deep or ask multiple detailed questions. Just capture any important practical information they want to share 6) if unclear yes/no or missing details when Yes, set routine_number = 5 and ask for clarification 7) if valid response provided, set routine_number = 6 and ask whether they played for Urmston Town last season (2024-25).""",
        
        6: """Task: Your current task is to: 1) take the response about whether they played for Urmston Town last season (2024-25) 2) accept a Yes/No response 3) if No, ask if they played for any team last season, and if so, ask for the name of the team and capture it as provided (no validation needed) 4) set routine_number = 8 and ask for their mobile telephone number.""",
        
        # Skip routine 7 - parent relationship not needed
        
        8: """Task: Your current task is to: 1) take their mobile telephone number (it MUST be a mobile number so we can send the payment link via SMS later in the process) 2) validate it follows UK format: mobile starts with 07 and has exactly 11 digits 3) remove any spaces, dashes, or brackets and check the format 4) if invalid format, set routine_number = 8 and ask them to provide a valid UK mobile number (07...) - explain that it must be a mobile number as we will send them important SMS messages 5) if valid, set routine_number = 9 and ask for their email address.""",
        
        9: """Task: Your current task is to: 1) take their email address 2) validate it contains exactly one @ symbol and at least one dot after the @ (format: something@something.something) 3) convert the entire email to lowercase 4) if invalid format, set routine_number = 9 and ask for a valid email address 5) if valid, set routine_number = 10 and ask for their consent to contact them by email and SMS with club communications throughout the season.""",
        
        10: """Task: Your current task is to: 1) take their response about consent to contact them by email and SMS with club communications 2) accept Yes/No response (normalize 'yes', 'yeah', 'ok', 'sure', 'no problem' to 'Yes' and 'no', 'nope', 'don't want to' to 'No') 3) explain this covers general club communications 4) if unclear response, set routine_number = 10 and ask for clarification 5) if consent given (Yes or No), set routine_number = 12 and ask for their postcode.""",
        
        # Skip routine 11 - already have DOB from routine 3
        
        12: """Task: Your current task is to: 1) take their postcode 2) clean it (remove spaces, convert to uppercase) and validate it's UK format 3) if postcode looks invalid (not UK format), set routine_number = 12 and ask for clarification 4) if valid postcode provided, set routine_number = 13 and ask for their house number.""",
        
        13: """Task: Your current task is to: 1) take their house number 2) accept any format (numbers, letters, flat numbers like '12a', '5B', 'Flat 2', etc.) 3) if house number seems unclear, set routine_number = 13 and ask for clarification 4) if house number provided and seems ok, use the function 'address_lookup' with the postcode and house number to find their full address 5) if no address returned or lookup failed, then set routine_number = 14 and ask them to enter their full address manually 6) if address returned successfully, set routine_number = 15 and show them the formatted address asking for confirmation that it's correct.""",
        
        14: """Task: Your current task is to: 1) take their manually entered full address 2) do a visual check to ensure it looks like a valid UK address format: has house number/name, street name, area/town, and UK postcode (2 letters, 1-2 numbers, space, 1 number, 2 letters like M32 8JL) 3) check it includes Manchester/Stretford/Urmston area or other recognizable UK location 4) if the address looks incomplete, badly formatted, or not UK, set routine_number = 14 and ask for a more complete address 5) if the address looks reasonable and complete, set routine_number = 15 and show them the address asking for confirmation that it's correct.""",
        
        15: """Task: Your current task is to: 1) take the response about whether the shown address is correct 2) accept Yes/No response (normalize 'yes', 'correct', 'right', 'that's it' to 'Yes' and 'no', 'wrong', 'not right', 'incorrect' to 'No') 3) if they say No or the address is wrong, set routine_number = 14 and ask them to provide their correct full address manually 4) if they confirm Yes or the address is correct, set routine_number = 28 and thank them for all the information provided so far, list all the info collected and ask them to confirm all the details are correct.""",
        
        # Skip routines 16-24 - all parent/child specific
        
        28: """Task: Your current task is to: 1) take their response about whether all the information is correct 2) if they say No or want to make changes, DO NOT proceed to step 3 below. Instead, set routine_number = 28, ask what needs to be corrected and take the new or updated information. You only need to show the changes made when reconfirming any changed data. 3) if they confirm all information is correct, set routine_number = 29 and explain that you now need to take a one-off annual signing-on fee of £45, and also setup a Direct Debit monthly subscription fee of £27.50. To do this you will send them a payment link via SMS, which will allow them to make payment and setup a monthly subscription payment via Direct Debit at their convenience. Advise that the monthly subscription is for September to May only (9 months). Before you move on, ask them for their preferred payment day so you can set up the payment link. Advise that this can be any day in the month, or the last day of each month.""",
        
        29: """Task: Your current task is to: 1) take their preferred payment day. This can be any day in the month, or the last day of each month. If it's the last day of the month then the value will be recorded as -1 as this is how our GoCardless payment system handles the last day of any month 2) if they do not provide a valid preferred payment day, set routine_number = 29 and ask for a valid payment day. DO NOT proceed to step 3 below until you have received a VALID preferred payment day 3) if they do provide a valid payment day, call the function create_payment_token which will create a GoCardless billings_request_id and return payment amounts 4) once you have created the id and received the payment amounts (look for signing_fee_amount_pounds and monthly_amount_pounds in the result), run the function update_reg_details_to_db which will write all the registration info you have captured so far plus the payment amounts to the registrations_2526 db table. Then set routine_number = 30, advise them that a payment link has now been sent to them via SMS and ask them to check if they have received the payment link or not but advise them NOT to close the chat whilst they are checking! This is the only question we need to ask here. Also, as the link was sent by SMS, DO NOT advise them to check spam, or advise them we can resend.""",
        
        30: """Task: Your current task is to: 1) take their response as to whether or not they have received the payment link via SMS. 2) if they indicate they have not, then advise them to email admin@urmstontownjfc.co.uk and someone will get back to them and assist. Never offer to resend by email, or resend the SMS as we can't currently do that. The only way we can help is if they email us. 3) if they indicate they have received the payment link via SMS, bring to their attention that we still have some information to collect from them in this chat, but remind them that within the next 7 days, they MUST click the link in the SMS message, make payment and setup subscription in order to be registered. Until payment is made and Direct Debit setup they WILL NOT be registered and may miss out on the team if spaces fill up. 4) In either scenario of them indicating they have received or not received the payment link, the next thing to do is to determine whether they need a new kit. To do this, check your conversation history to see if they answered 'No' to being asked whether they played for Urmston Town last season. If they did imply 'No' to that question, set routine_number = 32, then ask them to choose their kit size. The kits come in sizes: S, M, L, XL, 2XL, 3XL. Show the sizes clearly and ask them to choose. 5) If in the conversation history they did imply they played for Urmston Town last season, then call the function check_if_kit_needed to see whether their team is due a new kit. If the result returned implies 'No', then set routine = 34 and explain that next they need to upload a passport-style photo for ID purposes by clicking the + symbol in the chat window and uploading a file. 6) If the result returned from the check_if_kit_needed function implies 'Yes', then, set routine_number = 32, then ask them to choose their kit size.""",
        
        32: """Task: Your current task is to: 1) take their response for the kit size selection 2) validate that the response matches one of the valid kit sizes: S, M, L, XL, 2XL, or 3XL (accept variations like 'small', 'medium', 'large', 'extra large', '2 XL', etc. and normalize them to the correct format) 3) if the response cannot be understood or doesn't match any valid kit size, set routine_number = 32 and ask them to choose from the available kit sizes, showing the options clearly 4) if a valid kit size is provided, set routine_number = 33 and ask them to choose their shirt number. Explain that shirt numbers range from 1 to 49, and ask what number they would prefer. Also advise that if they are a goalkeeper they will need to choose either number 1 or 12.""",
        
        33: """Task: Your current task is to: 1) take their response for the shirt number selection 2) validate that the response is a number between 1 and 49 (accept '1', 'one', 'number 7', etc. and convert to integer) 3) if the response is not a valid number between 1-49, set routine_number = 33 and ask them to choose a valid shirt number between 1 and 49 4) if a valid shirt number is provided, use the function 'check_shirt_number_availability' with the team name, age_group (extract both from conversation history), and requested_shirt_number to check if it's available 5) if the shirt number is already taken, set routine_number = 33 inform them that number is taken (whilst avoiding exposing the name of the player which has taken shirt number already), then ask them to choose a different number 6) if the shirt number is available, use the function update_kit_details_to_db to write kit details to db, set routine_number = 34, confirm kit details saved and explain that next they need to upload a passport-style photo for ID purposes by clicking the + symbol in the chat window and uploading a file.""",
        
        34: """Task: Your current task is to: 1) take their uploaded photo 2) validate that they have indeed uploaded an image of an adult and that the image is the correct format (.jpg, .png, .heic, .webp) and it meets our requirement of being a passport style photo. Do not be too strict about this though, as it's only used as a proof of ID in a grassroots football league. If the photo is not valid for any reason then set routine_number = 34 and ask them to upload a valid image providing a reason why you have determined it not to be valid 3) if a valid image is provided, use the function 'upload_photo_to_s3' (adhering to the function schemas by extracting any information you need from the conversation history). 4) if the 'upload_photo_to_s3' returns successfully then use the function 'update_photo_link_to_db' to write the link to the db 5) once the db write has returned successfully, then set routine_number = 35, advise that photo uploaded successfully and registration has been completed pending payment and Direct Debit setup via the GoCardless link they received. Once payment is completed they will receive a confirmation SMS. If you use any coloured emoji spheres in your response, please only use blue or yellow ones as they reflect the club colours.""",
        
        35: """Task: Your current task is to respond to any query helpfully as the registration has now completed.""",
    }
    
    @classmethod
    def get_routine_message(cls, routine_number: int) -> str:
        """
        Get the routine message for a specific routine number.
        
        Args:
            routine_number: The routine step number
            
        Returns:
            The routine message string, or empty string if routine_number not found
        """
        return cls.ROUTINES.get(routine_number, "")
    
    @classmethod
    def get_available_routines(cls) -> list:
        """Get list of all available routine numbers."""
        return list(cls.ROUTINES.keys())
    
    @classmethod
    def get_flow_mapping(cls) -> dict:
        """
        Get the mapping of the adult registration flow.
        Shows how routines connect to each other.
        """
        return {
            1: [3, 32, 34],  # Name -> DOB or Kit selection or Photo
            3: [4],          # DOB -> Gender
            4: [5],          # Gender -> Medical issues
            5: [6],          # Medical -> Previous season
            6: [8],          # Previous season -> Mobile
            8: [9],          # Mobile -> Email
            9: [10],         # Email -> Consent
            10: [12],        # Consent -> Postcode
            12: [13],        # Postcode -> House number
            13: [14, 15],    # House number -> Manual address or Confirm address
            14: [15],        # Manual address -> Confirm address
            15: [28],        # Confirm address -> Confirm all details
            28: [28, 29],    # Confirm all -> Corrections or Payment day
            29: [30],        # Payment day -> SMS check
            30: [32, 34],    # SMS check -> Kit or Photo
            32: [33],        # Kit size -> Shirt number
            33: [34],        # Shirt number -> Photo
            34: [35],        # Photo -> Complete
            35: []           # Complete - no further steps
        }