# backend/tools/airtable/table_schema/__init__.py
# Table schema definitions for Airtable tables
# This package contains schema definitions that describe the structure,
# fields, relationships, and metadata for each Airtable table 